package com.home.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.home.entity.Admin;
import com.home.entity.AdminLogin;
import com.home.services.AdminService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Transactional
@Controller
public class AdminLoginController {
	
	@Autowired
	private AdminService adminservice;
	
	@GetMapping("/loginAdmin")
	public String getLogin(Model model) {
		model.addAttribute("adminlogin", new AdminLogin());
		return "adminLogin";
	}
	
	@PostMapping("/adminLoginStatus")
	public String getlogStatus(@Valid @ModelAttribute("adminlogin") AdminLogin adminlogin , BindingResult bindingResult, Model model) {
		if(bindingResult.hasErrors()) {
			return "adminLogin";
		}
		List<Admin> adminList = adminservice.adminList();
		boolean found = false;
		for(Admin ad : adminList) {
			if(ad.getUsername().equals(adminlogin.getUsername()) && ad.getPassword().equals(adminlogin.getPassword())) {
				found = true;
				break;
			}
		}
		if(found == true) {
			return "adminDash";
		}else {
			model.addAttribute("error", "Enter Valid Username and Password");
		

			return "adminLogin";
		}
		
	}
}
