package com.home.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.home.entity.Doner;
import com.home.entity.User;
import com.home.services.DonerService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Controller
@Transactional
public class DonerController {
	
	@Autowired
	private DonerService donerservice;
	
	//To Create Doner
	@GetMapping("/donate")
	public String saveDoner(Model model) {
		model.addAttribute("doner", new Doner());
		return "doner";
	}
	
	//To Save Doner
	@PostMapping("/donateStatus")
	public String getDonerStatus(@Valid @ModelAttribute("doner") Doner doner, BindingResult bindResult) {
		if(bindResult.hasErrors()) {
			return "doner";
		}
		donerservice.saveNew(doner);
		return "redirect:/home";
	}
	
	//To display all Doner
	@GetMapping("/doner/display")
	public String getAllDoner(Model model) {
		List<Doner> donerList = donerservice.donerList();
		model.addAttribute("doner", donerList);
		return "adminDoner";
	}
	
	//To Delete Doner by ID
	@PostMapping("/doner/delete")
	public String getDelete(@RequestParam("id") int donerID, Model model) {
		donerservice.deleteByID(donerID);
		String deleteMessage ="Doner succesfully deleated with ID:"+donerID;
		model.addAttribute("message", deleteMessage);
		return "redirect:/doner/display";	
	}
	
	//To Update Doner by ID
	@GetMapping("/doner/edit")
	public String getEditForm(@RequestParam("id") int donerID, Model model) {
		Doner byID = donerservice.findByID(donerID);
		model.addAttribute("doner", byID);
		return "updateDoner";
	}
	
	public String getUpdate(@Valid @ModelAttribute("doner") Doner doner, BindingResult bindresult) {
		if(bindresult.hasErrors()) {
			return "updateDoner";
		}
		donerservice.updateDoner(doner);
		return "redirect:/doner/display";
		
	}
}
