package com.home.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.home.entity.Post;
import com.home.services.PostService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Transactional
@Controller
public class PostController {
	
	private PostService postservice;

	@Autowired
	public PostController(PostService postservice) {
		super();
		this.postservice = postservice;
	}
	
	//To create post
	@GetMapping("/addPost")
	public String savePost(Model model) {
		model.addAttribute("post", new Post());
		return "postForm";	
	}
	
	//To save all Post
	@PostMapping("/postStatus")
	public String getPostStatus(@Valid @ModelAttribute("post") Post post , BindingResult bindResult) {
		if(bindResult.hasErrors()) {
			return "postForm";
		}
		postservice.saveNew(post);
		return "dashboard";	
	}

	//To display all Post
		@GetMapping("/post/display")
		public String getAllPost(Model model) {
			List<Post> postList = postservice.postList();
			model.addAttribute("post", postList);
			return "adminPost";
		}
		
		//To Delete Post by ID
		@PostMapping("/post/delete")
		public String getDelete(@RequestParam("id") int donerID, Model model) {
			postservice.deleteById(donerID);
			String deleteMessage ="Doner succesfully deleated with ID:"+donerID;
			model.addAttribute("message", deleteMessage);
			return "redirect:/post/display";	
		}
		
		//To Update Post by ID
		@GetMapping("/post/edit")
		public String getEditForm(@RequestParam("id") int postID, Model model) {
			Post byID = postservice.findByID(postID);
			model.addAttribute("post", byID);
			return "updatePost";
		}
		
		public String getUpdate(@Valid @ModelAttribute("post") Post post, BindingResult bindresult) {
			if(bindresult.hasErrors()) {
				return "updatePost";
			}
			postservice.updatePost(post);
			return "redirect:/post/display";
			
		}
}