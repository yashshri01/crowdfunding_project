package com.home.services;

import java.util.List;

import com.home.entity.User;

public interface UserService {
	
	public User saveRegistred(User user);
	
	public List<User> userList();
	
	public User updateUser(User user);
	
	public void deleteByID(int id);
	
	public User findByID(int id);
}
