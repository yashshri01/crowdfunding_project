package com.home.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.dao.UserRepository;
import com.home.entity.User;

@Service
public class UserServiceImp implements UserService{
	
	private UserRepository userRepo;
	
	@Autowired
	public UserServiceImp(UserRepository userRepo) {
		super();
		this.userRepo = userRepo;
	}

	@Override
	public User saveRegistred(User user) {
		return userRepo.save(user);
	}

	@Override
	public List<User> userList() {
		List<User> allUser = userRepo.findAll();
		return allUser;
	}

	@Override
	public User updateUser(User user) {
		return userRepo.save(user);
	}
	
	@Override
	public User findByID(int id) {
		Optional<User> byId = userRepo.findById(id);
		User user = byId.get();
		return user;
	}

	@Override
	public void deleteByID(int id) {
		userRepo.deleteById(id);
	}

	

}
