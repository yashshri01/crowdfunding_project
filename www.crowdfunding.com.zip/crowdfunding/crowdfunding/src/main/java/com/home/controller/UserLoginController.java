package com.home.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.home.entity.User;
import com.home.entity.UserLogin;
import com.home.services.UserService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Transactional
@Controller
public class UserLoginController {
	
	@Autowired
	private UserService userservice;
	
	@GetMapping("/loginUser")
	public String getLogin(Model model) {
		model.addAttribute("userlogin", new UserLogin());
		return "userLogin";	
	}
	
	@PostMapping("/loginStatus")
	public String getlogStatus(@Valid @ModelAttribute("userlogin") UserLogin userlogin, BindingResult bindingResult, Model model) {

		if (bindingResult.hasErrors()) {
			return "userLogin";
		}

		List<User> dbRegister = (List<User>) userservice.userList();
//		int id = 0;
		boolean found = false;
		for (User rs : dbRegister) {
			if (rs.getUsername().equals(userlogin.getUsername()) && rs.getPassword().equals(userlogin.getPassword())) {
				found = true;
				break;
			}
		}
		if (found == true) {
			return "dashboard";
		} else {
			model.addAttribute("error", "Enter Valid Username and Password");
		

			return "userLogin";
		}

	}
}
