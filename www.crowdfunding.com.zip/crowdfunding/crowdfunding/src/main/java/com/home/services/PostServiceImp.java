package com.home.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.dao.PostRepository;
import com.home.entity.Post;

@Service
public class PostServiceImp implements PostService{
	
	private PostRepository postrepo;
	
	@Autowired
	public PostServiceImp(PostRepository postrepo) {
		super();
		this.postrepo = postrepo;
	}

	@Override
	public Post saveNew(Post post) {
		return postrepo.save(post);
	}

	@Override
	public List<Post> postList() {
		List<Post> allPost = postrepo.findAll();
		return allPost;
	}

	@Override
	public Post updatePost(Post post) {
		return postrepo.save(post);
	}

	@Override
	public void deleteById(int id) {
		postrepo.deleteById(id);
	}

	@Override
	public Post findByID(int id) {
		Optional<Post> byId = postrepo.findById(id);
		Post post = byId.get();
		return post;
	}

}
