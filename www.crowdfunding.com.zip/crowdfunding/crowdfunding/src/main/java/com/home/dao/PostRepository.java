package com.home.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.home.entity.Post;

public interface PostRepository extends JpaRepository<Post, Integer>{

}
