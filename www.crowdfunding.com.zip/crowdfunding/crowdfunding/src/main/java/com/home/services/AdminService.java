package com.home.services;

import java.util.List;

import com.home.entity.Admin;


public interface AdminService {
	
	public Admin saveNew(Admin admin);
	
	public List<Admin> adminList();
	
	public Admin updateAdmin(Admin admin);
	
	public void deleteById(int id);
	
	public Admin findByID(int id);

}
