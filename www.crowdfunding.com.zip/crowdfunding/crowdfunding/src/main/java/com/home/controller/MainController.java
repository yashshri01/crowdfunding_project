package com.home.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.transaction.Transactional;

@Transactional
@Controller
public class MainController {
	
	@GetMapping("/home")
	public String getHome() {
		return "index";
	}
	
	@GetMapping("/adminHome")
	public String getAdminDash() {
		return "adminDash";
	}
	
}
