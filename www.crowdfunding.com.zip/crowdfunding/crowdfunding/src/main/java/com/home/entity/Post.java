package com.home.entity;

import java.sql.Date;
import java.util.Arrays;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
public class Post {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;

	@NotBlank(message = "Name is mandatory")
	private String name;

	@NotBlank(message = "Reason is mandatory")
	private String reason;

	@NotBlank(message = "Description is mandatory")
	private String description;

	@NotNull(message = "Goal amount is mandatory")
	@Digits(integer = 10, fraction = 2, message = "Invalid goal amount")
	private String goalAmount;
	
	@Lob
	@Column(name="sample", length=10000000)
	private byte[] photo;
	
	@Lob
	@Column(name = "personal_document", length = 10000000)
	private byte[] personalDocument;

	@Lob
	@Column(name = "medical_document", length = 10000000)
	private byte[] medicalDocument;
	
	@NotBlank(message = "Bank detail is mandatory")
	private String bankDetail;
	
	
	@NotNull(message = "End date is mandatory")
	private Date endDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGoalAmount() {
		return goalAmount;
	}

	public void setGoalAmount(String goalAmount) {
		this.goalAmount = goalAmount;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public byte[] getPersonalDocument() {
		return personalDocument;
	}

	public void setPersonalDocument(byte[] personalDocument) {
		this.personalDocument = personalDocument;
	}

	public byte[] getMedicalDocument() {
		return medicalDocument;
	}

	public void setMedicalDocument(byte[] medicalDocument) {
		this.medicalDocument = medicalDocument;
	}

	public String getBankDetail() {
		return bankDetail;
	}

	public void setBankDetail(String bankDetail) {
		this.bankDetail = bankDetail;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Post(int id, String name, String reason, String description, String goalAmount, byte[] photo,
			byte[] personalDocument, byte[] medicalDocument, String bankDetail, Date endDate) {
		super();
		this.id = id;
		this.name = name;
		this.reason = reason;
		this.description = description;
		this.goalAmount = goalAmount;
		this.photo = photo;
		this.personalDocument = personalDocument;
		this.medicalDocument = medicalDocument;
		this.bankDetail = bankDetail;
		this.endDate = endDate;
	}

	public Post() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Post [id=" + id + ", name=" + name + ", reason=" + reason + ", description=" + description
				+ ", goalAmount=" + goalAmount + ", photo=" + Arrays.toString(photo) + ", personalDocument="
				+ Arrays.toString(personalDocument) + ", medicalDocument=" + Arrays.toString(medicalDocument)
				+ ", bankDetail=" + bankDetail + ", endDate=" + endDate + "]";
	}
	
	
}
