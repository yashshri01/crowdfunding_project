package com.home.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.home.entity.Doner;

public interface DonerRepository extends JpaRepository<Doner, Integer>{

}
