package com.home.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.dao.DonerRepository;
import com.home.entity.Doner;

@Service
public class DonerServiceImp implements DonerService{
	
	@Autowired
	private DonerRepository donerRepo;

	@Override
	public Doner saveNew(Doner doner) {
		return donerRepo.save(doner);
	}

	@Override
	public List<Doner> donerList() {
		List<Doner> alldoner = donerRepo.findAll();
		return alldoner;
	}

	@Override
	public Doner updateDoner(Doner doner) {
		return donerRepo.save(doner);
	}

	@Override
	public void deleteByID(int id) {
		donerRepo.deleteById(id);
	}

	@Override
	public Doner findByID(int id) {
		Optional<Doner> byId = donerRepo.findById(id);
		Doner doner = byId.get();
		return doner;
	}

}
