package com.home.services;

import java.util.List;

import com.home.entity.Post;

public interface PostService {
	
	public Post saveNew(Post post);
	
	public List<Post> postList();
	
	public Post updatePost(Post post);
	
	public void deleteById(int id);
	
	public Post findByID(int id);
}
