package com.home.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.dao.AdminRepository;
import com.home.entity.Admin;

@Service
public class AdminServiceImp implements AdminService{
	
	@Autowired
	private AdminRepository adminRepo;

	@Override
	public Admin saveNew(Admin admin) {
		return adminRepo.save(admin);
	}

	@Override
	public List<Admin> adminList() {
		List<Admin> all = adminRepo.findAll();
		return all;
	}

	@Override
	public Admin updateAdmin(Admin admin) {
		return adminRepo.save(admin);
	}

	@Override
	public void deleteById(int id) {
		adminRepo.deleteById(id);
	}

	@Override
	public Admin findByID(int id) {
		Optional<Admin> byId = adminRepo.findById(id);
		Admin admin = byId.get();
		return admin;
	}

}
