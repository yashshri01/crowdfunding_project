package com.home.services;

import java.util.List;

import com.home.entity.Doner;

public interface DonerService {

	public Doner saveNew(Doner doner);
	
	public List<Doner> donerList();
	
	public Doner updateDoner(Doner doner);
	
	public void deleteByID(int id);
	
	public Doner findByID(int id);
}
