package com.home.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.home.dao.AdminRepository;
import com.home.entity.Admin;
import com.home.services.AdminService;
import com.home.services.DonerService;
import com.home.services.PostService;
import com.home.services.UserService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Controller
@Transactional
public class AdminController {
	
	@Autowired
	private AdminService adminservice;
	
	//To Create admin
	@GetMapping("/registerAdmin")
	public String saveAdmin(Model model) {
		model.addAttribute("admin", new Admin());
		return "adminRegister";
	}
	
	//To Save admin
	@PostMapping("/adminRegistrationStatus")
	public String getAdminregStatus(@Valid @ModelAttribute("admin") Admin admin, BindingResult bindResult) {
		if(bindResult.hasErrors()) {
			return "adminRegister";
		}
		adminservice.saveNew(admin);
		return "redirect:/loginAdmin";	
	}
	
	
}
