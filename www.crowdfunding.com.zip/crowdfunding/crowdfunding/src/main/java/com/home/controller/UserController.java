package com.home.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.home.entity.User;
import com.home.services.UserService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Transactional
@Controller
public class UserController {
	
	private UserService userservice;
	
	@Autowired
	public UserController(UserService userservice) {
		super();
		this.userservice = userservice;
	}
	
	//To Create User
	@GetMapping("/registerUser")
	public String saveUser(Model model) {
		model.addAttribute("user", new User());
		return "userRegister";
	}
	
	//To Save User
	@PostMapping("/registartionStatus")
	public String getRegistrationStatus(@Valid @ModelAttribute("user") User user, BindingResult bindResult) {
		if(bindResult.hasErrors()) {
			return "userRegister";
		}
		userservice.saveRegistred(user);
		return "redirect:/loginUser";	
	}
	
	//To display all User
	@GetMapping("/user/display")
	public String getAllUser(Model model) {
		List<User> userList = userservice.userList();
		model.addAttribute("user", userList);
		return "adminUser";
	}
	
	//To Delete User by ID
	@PostMapping("/user/delete")
	public String getDelete(@RequestParam("id") int userID, Model model) {
		userservice.deleteByID(userID);
		String deleteMessage ="User succesfully deleated with ID:"+userID;
		model.addAttribute("message", deleteMessage);
		return "redirect:/user/display";	
	}
	
	//To Update User by ID
	@GetMapping("/user/edit")
	public String getEditForm(@RequestParam("id") int userID, Model model) {
		User byID = userservice.findByID(userID);
		model.addAttribute("user", byID);
		return "updateUser";
	}
	
	public String getUpdate(@Valid @ModelAttribute("user") User user, BindingResult bindresult) {
		if(bindresult.hasErrors()) {
			return "updateUser";
		}
		userservice.updateUser(user);
		return "redirect:/user/display";
		
	}
	
}
